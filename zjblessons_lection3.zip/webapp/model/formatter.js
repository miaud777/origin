sap.ui.define([
	] , function () {
		"use strict";

		return {

			/**
			 * Rounds the number unit value to 2 digits
			 * @public
			 * @param {string} sValue the number string to be rounded
			 * @returns {string} sValue with 2 digits rounded
			 */
			numberUnit : function (sValue) {
				if (!sValue) {
					return "";
				}
				return parseFloat(sValue).toFixed(2);
			},
			
			formatDates : function (sDate) {
				var d = new Date(sDate);
				
				var yyyy = "" + d.getFullYear();
				
				var mon = ("0" + (d.getMonth()));
				mon = mon.substr(mon.length - 2);
				
				var dd = ("0" + d.getDay());
				dd = dd.substr(dd.length - 2);
				
				var hh = ("0" + d.getHours());
				hh = hh.substr(hh.length - 2);
				
				var mm = ("0" + d.getMinutes());
				mm = mm.substr(mm.length - 2);
				
				var l_str = hh + ":" + mm + " " + dd + "/" + mon + "/" + yyyy;
				
				return l_str;
				
				// return d.toLocaleDateString('ru-RU');
			}

		};

	}
);
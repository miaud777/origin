/*global QUnit*/

jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

sap.ui.require([
	"sap/ui/test/Opa5",
	"zjblessons/zjblessons_lection3/test/integration/pages/Common",
	"sap/ui/test/opaQunit",
	"zjblessons/zjblessons_lection3/test/integration/pages/Worklist",
	"zjblessons/zjblessons_lection3/test/integration/pages/Object",
	"zjblessons/zjblessons_lection3/test/integration/pages/NotFound",
	"zjblessons/zjblessons_lection3/test/integration/pages/Browser",
	"zjblessons/zjblessons_lection3/test/integration/pages/App"
], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "zjblessons.zjblessons_lection3.view."
	});

	sap.ui.require([
		"zjblessons/zjblessons_lection3/test/integration/WorklistJourney",
		"zjblessons/zjblessons_lection3/test/integration/ObjectJourney",
		"zjblessons/zjblessons_lection3/test/integration/NavigationJourney",
		"zjblessons/zjblessons_lection3/test/integration/NotFoundJourney",
		"zjblessons/zjblessons_lection3/test/integration/FLPIntegrationJourney"
	], function () {
		QUnit.start();
	});
});
sap.ui.define([
		"zjblessons/zjblessons_lection3/controller/BaseController"
	], function (BaseController) {
		"use strict";

		return BaseController.extend("zjblessons.zjblessons_lection3.controller.NotFound", {

			/**
			 * Navigates to the worklist when the link is pressed
			 * @public
			 */
			onLinkPressed : function () {
				this.getRouter().navTo("worklist");
			}

		});

	}
);